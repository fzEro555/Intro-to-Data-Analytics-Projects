import

def count_reddit_data():
    all_counts = []
    return


if __name__ is "__main__":
    count_reddit_data()
