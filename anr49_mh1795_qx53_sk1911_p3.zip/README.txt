﻿we have zipped up our entire project, but only describe the folders that are new for project 3. To run everything necessary for project 3, run main.py which is located in amqs_p3.zip


amqs_p3.zip
        main.py
* the main script 
./node_modules
* package used for word cloud
./sentiment_analysis
* all_sent.json
      * the overall sentiment scores for each of the media sources, outputted from sentiment_analysis.py
* guardian_sentiment_date.csv, nytimes_sentiment_date.csv, reddit_sentiment_date.csv
      * sentiment calculations by day created by sentiment_analysis_date.py
* sent_overlay.py
      * uses reddit_sentiment_date.csv to create line charts by day showing sentiment scores
* sentiment_analysis.py
      * creates all_sent.json, calculates overall sentiment scores for all sources
* sentiment_analysis_date.py
      * creates guardian_sentiment_date.csv (and all other *_sentiment_date.csv) files
      * calculates sentiment scores for each source by day
./topic_modeling
* topic_modeling.py
      * generate 10 topics and print top 20 words for each data source 
* count_topics.py: 
      * count the number of topics that is about each topic
* plot_topics_distribution .py: 
      * plot the distribution of topics with time
* word_cloud_data_prep.py: 
      * prepare data for word cloud
* word_cloud_guardian.json 
   * word cloud for topics in guardian
* word_cloud_nytime.json 
   * word cloud for topics in nytime
* word_cloud_reddit.json 
   * word cloud for topics in reddit
* cloud.js
   * javascript used in word cloud
* drawWordCloud.js
   * javascript used in word cloud
./Visualization
* association_rules.html: d3 visualization for association rules
* irene_LG.py: Longitudinal graph in plotly depicting the number of mentions in each media for Hurricane Irene over a period of time.
* irma_LG.py: Longitudinal graph in plotly depicting the number of mentions in each media for Hurricane Irma over a period of time.
* harvey_LG.py: Longitudinal graph in plotly depicting the number of mentions in each media for Hurricane Harvey over a period of time.
* maria_LG.py: Longitudinal graph in plotly depicting the number of mentions in each media for Hurricane Maria over a period of time.
* reddit_mentions.py: Longitudinal graph depicting the number of mentions in Reddit data for Hurricane Irma, Harvey and Maria
   * Tableau map: Visualization of the amount of relief aid promised by each state. Link to the visualization: https://public.tableau.com/views/ContractsAmountStates-Hurricanes/Dashboard1?:embed=y&:display_count=yes  
* bubbles_each_hurricane.py: Bubble chart for spending in each hurricane in the FPDS data. X axis is date and Y axis is the number of contracts of the hurricane. While the size of each bubble is the amount of spending.
* barchart_spending.py: Bar chart for spending in each hurricane with X axis represents the date and Y axis represents the amount of spending.
amqs_writeup_p3.pdf
* write-up for project three
* includes a link to our website